
<template>
    <div>
      <!-- Sidebar  -->
         <div class="iq-sidebar">
            <div class="iq-sidebar-logo d-flex justify-content-between">
               <a href="/dashboard" class="header-logo">
                  <img src="images/logo.png" class="img-fluid rounded-normal" alt="">
                  <div class="logo-title">
                     <span class="text-danger text-uppercase">Server<span class="text-primary ml-1">360</span></span>
                  </div>
               </a>
               <div class="iq-menu-bt-sidebar">
                  <div class="iq-menu-bt align-self-center">
                     <div class="wrapper-menu">
                        <div class="main-circle"><i class="ri-arrow-left-s-line"></i></div>
                        <div class="hover-circle"><i class="ri-arrow-right-s-line"></i></div>
                     </div>
                  </div>
               </div>
            </div>
            <div id="sidebar-scrollbar">
               <nav class="iq-sidebar-menu">
                  <ul id="iq-sidebar-toggle" class="iq-menu">
                     <li>
                        <a href="calendar.html" class="iq-waves-effect"><i class="las la-calendar iq-arrow-left"></i><span>Calendar</span></a>
                     </li>
                     <li>
                        <router-link to="/dashboard" class="iq-waves-effect"><i class="las la-calendar iq-arrow-left"></i><span>Dashboard</span></router-link> 
                     </li>
                     
                  </ul>
               </nav>
               <div id="sidebar-bottom" class="p-3 position-relative">
                  <div class="iq-card bg-primary rounded">
                     <div class="iq-card-body">
                        <div class="sidebarbottom-content">
                           <div class="image"><img src="images/page-img/side-bkg.png" alt=""></div>
                           <h5 class="mb-3 text-white">Upgrade to PRO</h5>
                           <p class="mb-0 text-light">Become a pro user & enjoy more.</p>
                           <button type="submit" class="btn btn-white w-100  mt-4 text-primary viwe-more">View More</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
    </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Dashboard',
  components: {
    // HelloWorld
  }
}
</script>
