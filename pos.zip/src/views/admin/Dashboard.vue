
<template>
    <div>
      <!-- Wrapper Start -->
      <div class="wrapper">
        <SideBar />
        <div id="content-page" class="content-page">
            <div class="container-fluid">
               <div class="row content-body">
                <div class="col-lg-4">
                  <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
                      <div class="iq-card-header d-flex justify-content-between">
                        <div class="iq-header-title">
                            <h4 class="card-title">Staff Details</h4>
                        </div>
                      </div>
                      <div class="iq-card-body">
                        <div class="col-md-12 table-responsive">
                          <form @submit.prevent="add_staff" class="row text-left">
                            
                            <div class="form-group col-md-3">
                              <label class="mb-0">Title</label>
                              <input class="form-control" v-model="current_staff.title" required>
                            </div>

                            <div class="form-group col-md-9">
                              <label class="mb-0">Name</label>
                              <input class="form-control" v-model="current_staff.name" required>
                            </div>

                            <div class="form-group col-md-12">
                              <label class="mb-0">Role</label>
                              <input class="form-control" v-model="current_staff.role" required>
                            </div>

                            <div class="form-group col-md-12">
                              <button type="submit" class="btn btn-primary">Add Staff</button>
                            </div>
                          </form>
                        </div>
                      </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="iq-card iq-card-block iq-card-stretch iq-card-height text-left">
                      <div class="iq-card-header d-flex justify-content-between">
                        <div class="iq-header-title">
                            <h4 class="card-title">Staffs</h4>
                        </div>
                        <div class="iq-card-header-toolbar d-flex align-items-center">
                            <div class="dropdown">
                              <span class="dropdown-toggle text-primary" id="dropdownMenuButton2" data-toggle="dropdown">
                              <i class="ri-more-2-fill"></i>
                              </span>
                              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton2">
                                  <a class="dropdown-item" href="#"><i class="ri-eye-fill mr-2"></i>View</a>
                                  <a class="dropdown-item" href="#"><i class="ri-delete-bin-6-fill mr-2"></i>Delete</a>
                                  <a class="dropdown-item" href="#"><i class="ri-pencil-fill mr-2"></i>Edit</a>
                                  <a class="dropdown-item" href="#"><i class="ri-printer-fill mr-2"></i>Print</a>
                                  <a class="dropdown-item" href="#"><i class="ri-file-download-fill mr-2"></i>Download</a>
                              </div>
                            </div>
                        </div>
                      </div>
                      <div class="iq-card-body">
                        <div class="col-md-12 table-responsive" v-if="staffs_record">
                          <table class="table table-bordered">
                            <thead class="text-left">
                              <th>S/N</th>
                              <th>Title</th>
                              <th>Name</th>
                              <th>Role</th>
                              <th>Action</th>
                            </thead>
                            <tbody class="text-left">
                              <!-- <tr>
                                <td>100</td>
                                <td>Mr</td>
                                <td>Ajasi</td>
                                <td>Bus</td>
                                <td>
                                  <div class="d-flex align-items-center list-user-action">
                                    <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="Edit" data-original-title="Edit" href="#"><i class="ri-pencil-line"></i></a>
                                    <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="#"><i class="ri-delete-bin-line"></i></a>
                                  </div>
                                </td>
                              </tr> -->

                              <tr v-bind:key="n" v-for="(r, n) in staffs_record">
                                <td>{{n+1}}</td>
                                <td>{{r.title}}</td>
                                <td>{{r.name}}</td>
                                <td>{{r.role}}</td>
                                <td>
                                  <div class="d-flex align-items-center list-user-action">
                                    <button class="iq-bg-primary"  @click="edit_staff(r)"><i class="ri-pencil-line"></i></button>
                                    <button class="iq-bg-primary"  @click="delete_staff(r)"><i class="ri-delete-bin-line"></i></button>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        <div v-else>
                          <p>No Records</p>
                        </div>
                      </div>
                  </div>
                </div>

                <!-- loading modal -->
                <div class="col-md-12">
                  <div v-if="showLoadingModal">
                    <transition name="modal">
                      <div class="modal-mask">
                        <div class="modal-wrapper">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Loading...</h5>
                                
                              </div>
                              
                            </div>
                          </div>
                        </div>
                      </div>
                    </transition>
                  </div>
                </div>
                <!-- end loading modal -->

                <!-- delete modal -->
                <div class="col-md-12">
                  <div v-if="showPromptModal">
                    <transition name="modal">
                      <div class="modal-mask">
                        <div class="modal-wrapper">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Delete Staff</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true" @click="showPromptModal = false">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body text-left">
                                <p>Are you sure?</p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" @click="showPromptModal = false">Cancel</button>
                                <button type="button" class="btn btn-primary" @click="do_delete">Delete</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </transition>
                  </div>
                </div>
                <!-- end delete modal -->

                <!-- edit modal -->
                <div class="col-md-12">
                  <div v-if="showEditModal">
                    <transition name="modal">
                      <div class="modal-mask">
                        <div class="modal-wrapper">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Edit Staff</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true" @click="showEditModal = false">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body text-left">
                                <form @submit.prevent="do_edit" class="row text-left">
                            
                                  <div class="form-group col-md-3">
                                    <label class="mb-0">Title</label>
                                    <input class="form-control" v-model="current_staff.title" required>
                                  </div>

                                  <div class="form-group col-md-9">
                                    <label class="mb-0">Name</label>
                                    <input class="form-control" v-model="current_staff.name" required>
                                  </div>

                                  <div class="form-group col-md-12">
                                    <label class="mb-0">Role</label>
                                    <input class="form-control" v-model="current_staff.role" required>
                                  </div>

                                  <div class="form-group col-md-12">
                                    <button type="submit" class="btn btn-primary">Update Staff</button>
                                  </div>
                                </form>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" @click="showEditModal = false">Cancel</button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </transition>
                  </div>
                </div>
                <!-- end edit modal -->
               </div>
            </div>
        </div>
        <TopBar title="Staff List"/>
      </div>
      <!-- Wrapper END -->
    </div>
</template>

<script>
// @ is an alias to /src
import SideBar from '@/views/admin/SideBar.vue'
import TopBar from '@/views/admin/TopBar.vue'
import axios from "axios"

export default {
  name: 'Dashboard',
  data(){
    return{
      staffs_record: null,
      showPromptModal: false,
      showEditModal: false,
      current_staff : {
        title: null,
        name: null,
        role: null,
      }
    }
  },
  components: {
      SideBar,
      TopBar,
  },
  methods: {
    get_staff_records: function(){
      const url = `${this.$api_host}/staffs?api_token=${this.$api_key}`;
      axios.get(url)
        .then(response => {
          // console.log(response.data.response)
          if(response.data.success){
            this.staffs_record = response.data.response;
          }
          else{
            alert(response.data.response);
          }
        })
        .catch(error => console.log(error));
    },
    add_staff: function(){
      const url = `${this.$api_host}/staffs/create?api_token=${this.$api_key}`;
      axios.post(
        url,
        {
          title: this.current_staff.title,
          name: this.current_staff.name,
          role: this.current_staff.role
        }
        )
        .then(response => {
          // console.log(response.data.response)
          if(response.data.success){
            this.current_staff = {};
            this.get_staff_records();
          }
          else{
            alert(response.data.response);
          }
        })
        .catch(error => console.log(error));
    },
    delete_staff: function(r){
      this.current_staff = {};
      this.current_staff.id = r.id
      this.showPromptModal = true;
    },
    do_delete: function(){
      const url = `${this.$api_host}/staffs/delete/${this.current_staff.id}?api_token=${this.$api_key}`;
      axios.post(url)
        .then(response => {
          if(response.data.success){
            this.current_staff = {};
            this.get_staff_records();
            this.showPromptModal = false;
          }
          else{
            alert(response.data.response);
          }
        })
        .catch(error => console.log(error));
    },
    edit_staff: function(r){
      this.current_staff = {};

      this.current_staff = r;
      this.showEditModal = true;
    },
    do_edit: function(){
  
      const url = `${this.$api_host}/staffs/${this.current_staff.id}?api_token=${this.$api_key}`;
      axios.post(
        url,
        {
          title: this.current_staff.title,
          name: this.current_staff.name,
          role: this.current_staff.role
        }
        )
        .then(response => {
          if(response.data.success){
            this.current_staff = {};
            this.get_staff_records();
            this.showEditModal = false;
          }
          else{
            alert(response.data.response);
          }
        })
        .catch(error => console.log(error));
    }
  },
  created: function() {
    this.get_staff_records();
  }
}
</script>

<style>
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}

.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}

</style>