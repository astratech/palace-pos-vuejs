import Vue from 'vue'
// import './plugins/axios'
// import axios from 'axios'
import App from './App.vue'
import router from './router'

Vue.config.productionTip = false
Vue.prototype.$api_host = (Vue.config.productionTip) ? 'https://hostname' : 'http://127.0.0.1:8080/pos-api/api/v1'
Vue.prototype.$api_key = "IsIwnQR3Fm7qGyGN8D8wDjj4I9ZA5eCr1GnIpZCKqIKetfMofwyUOASv1KM8"
// Vue.use(axios)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
